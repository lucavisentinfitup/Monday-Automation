# Monday Automation - Vercel Deployment

## Come usare questo progetto

1. Installa le dipendenze:
   ```bash
   npm install
   ```

2. Deploy su Vercel:
   ```bash
   vercel
   ```

3. Imposta le variabili di ambiente su Vercel:
   - `MONDAY_API_KEY`: il tuo token API personale
   - `DEST_WORKSPACE_ID`: l'ID della workspace "FitUP - Cantieri Terminati"

4. Inserisci l'URL generato in Monday come webhook per "change_column_value" della colonna "Stato cantiere".

Enjoy! 🚀